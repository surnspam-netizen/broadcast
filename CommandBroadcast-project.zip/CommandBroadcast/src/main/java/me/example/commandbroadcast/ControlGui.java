package me.example.commandbroadcast;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Chest-style control panel for CommandBroadcast.
 * Open with /commandbroadcast (alias /cbc).
 */
public class ControlGui implements InventoryHolder {

    private static final int SLOT_INFO = 4;
    private static final int SLOT_ENABLED = 10;
    private static final int SLOT_ONLY_OPS = 11;
    private static final int SLOT_SHOW_NON_OPS = 12;
    private static final int SLOT_HIDE_SENSITIVE = 13;
    private static final int SLOT_RELOAD = 15;
    private static final int SLOT_CLOSE = 16;

    private final CommandBroadcast plugin;
    private final Inventory inventory;

    public ControlGui(CommandBroadcast plugin) {
        this.plugin = plugin;
        this.inventory = Bukkit.createInventory(this, 27,
                Component.text("CommandBroadcast Control", NamedTextColor.DARK_GRAY));
        render();
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void open(Player player) {
        player.openInventory(inventory);
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.2f);
    }

    // ------------------------------------------------------------------
    // Drawing
    // ------------------------------------------------------------------
    private void render() {
        ItemStack filler = item(Material.GRAY_STAINED_GLASS_PANE, Component.text(" "), List.of());
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, filler);
        }

        var cfg = plugin.getConfig();

        inventory.setItem(SLOT_INFO, item(Material.PAPER,
                name("CommandBroadcast", NamedTextColor.GOLD),
                List.of(
                        lore("Shows typed commands in chat.", NamedTextColor.GRAY),
                        lore("Click a toggle below to change it.", NamedTextColor.GRAY),
                        lore("Changes are saved instantly.", NamedTextColor.DARK_GRAY)
                )));

        inventory.setItem(SLOT_ENABLED, toggle(
                cfg.getBoolean("enabled", true),
                "Broadcasting",
                "Master switch for the whole plugin."));

        inventory.setItem(SLOT_ONLY_OPS, toggle(
                cfg.getBoolean("only-operators", false),
                "Only operator commands",
                "ON: only operators' commands are shown.",
                "OFF: every player's commands are shown."));

        inventory.setItem(SLOT_SHOW_NON_OPS, toggle(
                cfg.getBoolean("show-to-non-operators", true),
                "Visible to non-operators",
                "ON: everyone sees the messages.",
                "OFF: only operators and the console do."));

        inventory.setItem(SLOT_HIDE_SENSITIVE, toggle(
                cfg.getBoolean("hide-sensitive-commands", true),
                "Hide password commands",
                "ON: /login, /register etc. are never shown.",
                "Edit the list in config.yml (hidden-commands)."));

        inventory.setItem(SLOT_RELOAD, item(Material.ANVIL,
                name("Reload config", NamedTextColor.AQUA),
                List.of(lore("Re-read config.yml from disk.", NamedTextColor.GRAY))));

        inventory.setItem(SLOT_CLOSE, item(Material.BARRIER,
                name("Close", NamedTextColor.RED),
                List.of()));
    }

    private ItemStack toggle(boolean on, String title, String... description) {
        List<Component> lore = new ArrayList<>();
        for (String line : description) {
            lore.add(lore(line, NamedTextColor.GRAY));
        }
        lore.add(Component.empty());
        lore.add(lore("Click to turn " + (on ? "OFF" : "ON"), NamedTextColor.YELLOW));

        Component display = Component.text(title + ": ", NamedTextColor.WHITE)
                .append(Component.text(on ? "ON" : "OFF", on ? NamedTextColor.GREEN : NamedTextColor.RED))
                .decoration(TextDecoration.ITALIC, false);

        return item(on ? Material.LIME_CONCRETE : Material.RED_CONCRETE, display, lore);
    }

    private static Component name(String text, TextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private static Component lore(String text, TextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private static ItemStack item(Material material, Component displayName, List<Component> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(displayName);
        if (!lore.isEmpty()) meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    // ------------------------------------------------------------------
    // Clicking
    // ------------------------------------------------------------------
    public void handleClick(Player player, int slot) {
        switch (slot) {
            case SLOT_ENABLED -> flip(player, "enabled", true);
            case SLOT_ONLY_OPS -> flip(player, "only-operators", false);
            case SLOT_SHOW_NON_OPS -> flip(player, "show-to-non-operators", true);
            case SLOT_HIDE_SENSITIVE -> flip(player, "hide-sensitive-commands", true);
            case SLOT_RELOAD -> {
                plugin.reloadConfig();
                render();
                player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_USE, 0.4f, 1.4f);
                player.sendMessage(Component.text("CommandBroadcast config reloaded.", NamedTextColor.GREEN));
            }
            case SLOT_CLOSE -> player.closeInventory();
            default -> { /* decoration */ }
        }
    }

    private void flip(Player player, String key, boolean defaultValue) {
        boolean now = !plugin.getConfig().getBoolean(key, defaultValue);
        plugin.getConfig().set(key, now);
        plugin.saveConfig();
        render();
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, now ? 1.4f : 0.8f);
    }
}
