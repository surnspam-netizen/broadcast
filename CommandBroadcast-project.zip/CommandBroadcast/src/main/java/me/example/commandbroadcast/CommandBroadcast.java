package me.example.commandbroadcast;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextReplacementConfig;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.Locale;

public class CommandBroadcast extends JavaPlugin implements Listener, CommandExecutor {

    public static final String ADMIN_PERMISSION = "commandbroadcast.admin";

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("commandbroadcast");
        if (cmd != null) cmd.setExecutor(this);
        getLogger().info("CommandBroadcast enabled.");
    }

    // ------------------------------------------------------------------
    // /commandbroadcast  (opens the GUI)   /commandbroadcast reload
    // ------------------------------------------------------------------
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission(ADMIN_PERMISSION)) {
            sender.sendMessage(Component.text("You don't have permission to do that.", NamedTextColor.RED));
            return true;
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            sender.sendMessage(Component.text("CommandBroadcast config reloaded.", NamedTextColor.GREEN));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can open the GUI. Use /" + label + " reload from console.",
                    NamedTextColor.RED));
            return true;
        }

        new ControlGui(this).open(player);
        return true;
    }

    // ------------------------------------------------------------------
    // GUI click handling
    // ------------------------------------------------------------------
    @EventHandler
    public void onGuiClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof ControlGui gui)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!player.hasPermission(ADMIN_PERMISSION)) {
            player.closeInventory();
            return;
        }
        // Only react to clicks inside the GUI itself, not the player's own inventory
        if (event.getClickedInventory() == null
                || event.getClickedInventory() != event.getView().getTopInventory()) return;

        gui.handleClick(player, event.getSlot());
    }

    @EventHandler
    public void onGuiDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof ControlGui) {
            event.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------
    // Command broadcasting
    // ------------------------------------------------------------------
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!getConfig().getBoolean("enabled", true)) return;

        var player = event.getPlayer();

        // Skip players who are explicitly hidden
        if (player.hasPermission("commandbroadcast.hide")) return;

        // Optionally only broadcast operator commands
        if (getConfig().getBoolean("only-operators", false) && !player.isOp()) return;

        String message = event.getMessage(); // includes the leading "/"
        if (message.length() < 2) return;

        // Never broadcast sensitive commands (passwords etc.)
        if (getConfig().getBoolean("hide-sensitive-commands", true)) {
            String label = message.substring(1).split(" ")[0].toLowerCase(Locale.ROOT);
            if (label.contains(":")) label = label.substring(label.indexOf(':') + 1);
            List<String> hidden = getConfig().getStringList("hidden-commands");
            for (String h : hidden) {
                if (label.equalsIgnoreCase(h)) return;
            }
        }

        String format = getConfig().getString("format",
                "&8[&cCMD&8] &7{player}&8: &f{command}");

        Component line = LegacyComponentSerializer.legacyAmpersand()
                .deserialize(format.replace("{player}", player.getName()))
                .replaceText(TextReplacementConfig.builder()
                        .matchLiteral("{command}")
                        .replacement(Component.text(message))
                        .build());

        if (getConfig().getBoolean("show-to-non-operators", true)) {
            // Everyone online (and the console)
            Bukkit.broadcast(line);
        } else {
            // Operators + console only
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (online.isOp()) online.sendMessage(line);
            }
            Bukkit.getConsoleSender().sendMessage(line);
        }
    }
}
